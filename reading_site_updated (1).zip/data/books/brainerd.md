# Życie i Pamiętnik Dawida Brainerda  
**Autor:** Jonathan Edwards  

Liczba stron: 298

## Moje notatki
(Tutaj możesz dopisać swoje refleksje, cytaty, wnioski…)

